package ra.business;

import ra.entity.Book;
import ra.util.ConnectionDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookBusiness {
    private ConnectionDB connectionDB;
    public BookBusiness() {
        connectionDB = new ConnectionDB();
    }

    // Hiển thị danh sacsh sách chưa bị xoá
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        Connection conn = connectionDB.openConnection();
        if (conn != null) {
            try {
                String query = "SELECT * FROM Book WHERE IsDeleted=0";
                Statement statement = conn.createStatement();
                ResultSet rs = statement.executeQuery(query);
                while (rs.next()){
                    Book book = new Book();
                    book.setBookId(rs.getInt("BookId"));
                    book.setBookName(rs.getString("BookName"));
                    book.setTitle(rs.getString("Title"));
                    book.setAuthor(rs.getString("Author"));
                    book.setTotalPages(rs.getInt("TotalPages"));
                    book.getContent();
                    book.setPublisher(rs.getString("Publisher"));
                    book.setPrice(rs.getDouble("Price"));
                    book.setTypeId(rs.getInt("TypeId"));
                    book.setDeleted(rs.getBoolean("Deleted"));
                    books.add(book);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                connectionDB.closeConnection(conn, null);
            }
        }
        return books;
    }

    public void addBook(Scanner scanner) {
        Book book = new Book();
        book.inputData(scanner);

        Connection conn = connectionDB.openConnection();
        if (conn != null) {
            try {
                String query = "INSERT INTO Book (BookName, Title, Author, TotalPages, Content, Publisher, Price, TypeId) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, book.getBookName());
                ps.setString(2, book.getTitle());
                ps.setString(3, book.getAuthor());
                ps.setInt(4, book.getTotalPages());
                ps.setString(5, book.getContent());
                ps.setString(6, book.getPublisher());
                ps.setDouble(7, book.getPrice());
                ps.setInt(8, book.getTypeId());
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Tạo mới sách thành công.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                connectionDB.closeConnection(conn, null);
            }
        }
    }

    public void updateBook(Scanner scanner) {
        System.out.print("Nhập mã sách cần cập nhật: ");
        int bookId = scanner.nextInt();
        scanner.nextLine(); // Loại bỏ ký tự xuống dòng

        Connection conn = connectionDB.openConnection();
        if (conn != null) {
            try {
                // Kiểm tra sách có tồn tại không
                String selectQuery = "SELECT * FROM Book WHERE BookId = ?";
                PreparedStatement ps = conn.prepareStatement(selectQuery);
                ps.setInt(1, bookId);
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) {
                    System.out.println("Mã sách không tồn tại!");
                    return;
                }

                // Hiển thị thông tin hiện tại của sách
                Book book = new Book();
                book.setBookId(rs.getInt("BookId"));
                book.setBookName(rs.getString("BookName"));
                book.setTitle(rs.getString("Title"));
                book.setAuthor(rs.getString("Author"));
                book.setTotalPages(rs.getInt("TotalPages"));
                book.setContent(rs.getString("Content"));
                book.setPublisher(rs.getString("Publisher"));
                book.setPrice(rs.getDouble("Price"));
                book.setTypeId(rs.getInt("TypeId"));
                book.displayData();

                // Cho phép người dùng cập nhật thông tin sách
                System.out.println("Nhập tên sách mới (hoặc bỏ trống để giữ nguyên): ");
                String newBookName = scanner.nextLine();
                if (!newBookName.isEmpty()) {
                    book.setBookName(newBookName);
                }

                System.out.println("Nhập tiêu đề mới (hoặc bỏ trống để giữ nguyên): ");
                String newTitle = scanner.nextLine();
                if (!newTitle.isEmpty()) {
                    book.setTitle(newTitle);
                }

                System.out.println("Nhập tác giả mới (hoặc bỏ trống để giữ nguyên): ");
                String newAuthor = scanner.nextLine();
                if (!newAuthor.isEmpty()) {
                    book.setAuthor(newAuthor);
                }

                // Tiếp tục cập nhật các trường khác...

                // Thực hiện cập nhật
                String updateQuery = "UPDATE Book SET BookName = ?, Title = ?, Author = ? WHERE BookId = ?";
                ps = conn.prepareStatement(updateQuery);
                ps.setString(1, book.getBookName());
                ps.setString(2, book.getTitle());
                ps.setString(3, book.getAuthor());
                ps.setInt(4, bookId);
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Cập nhật sách thành công.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                connectionDB.closeConnection(conn, null);
            }
        }
    }

    // Xóa sách (thay đổi trạng thái IsDeleted)
    public void deleteBook(Scanner scanner) {
        System.out.print("Nhập mã sách cần xóa: ");
        int bookId = scanner.nextInt();

        Connection conn = connectionDB.openConnection();
        if (conn != null) {
            try {
                String updateQuery = "UPDATE Book SET IsDeleted = 1 WHERE BookId = ?";
                PreparedStatement ps = conn.prepareStatement(updateQuery);
                ps.setInt(1, bookId);
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Xóa sách thành công.");
                } else {
                    System.out.println("Không tìm thấy sách.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                connectionDB.closeConnection(conn, null);
            }
        }
    }


    public void displayBooksByPriceDescending() {
        Connection conn = connectionDB.openConnection();
        if (conn != null) {
            try {
                String query = "SELECT * FROM Book WHERE IsDeleted = 0 ORDER BY Price DESC";
                Statement statement = conn.createStatement();
                ResultSet rs = statement.executeQuery(query);

                List<Book> books = new ArrayList<>();
                while (rs.next()) {
                    Book book = new Book();
                    book.setBookId(rs.getInt("BookId"));
                    book.setBookName(rs.getString("BookName"));
                    book.setTitle(rs.getString("Title"));
                    book.setAuthor(rs.getString("Author"));
                    book.setTotalPages(rs.getInt("TotalPages"));
                    book.setContent(rs.getString("Content"));
                    book.setPublisher(rs.getString("Publisher"));
                    book.setPrice(rs.getDouble("Price"));
                    book.setTypeId(rs.getInt("TypeId"));
                    books.add(book);
                }

                if (books.isEmpty()) {
                    System.out.println("Không có cuốn sách nào.");
                } else {
                    System.out.println("Danh sách các cuốn sách theo giá giảm dần:");
                    for (Book book : books) {
                        book.displayData(); // Gọi phương thức displayData() để hiển thị chi tiết sách
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                connectionDB.closeConnection(conn, null);
            }
        }
    }

    public void searchBookByNameOrContent(Scanner scanner) {
        System.out.print("Nhập tên sách hoặc nội dung muốn tìm: ");
        String keyword = scanner.nextLine();

        Connection conn = connectionDB.openConnection();
        if (conn != null) {
            try {
                String query = "SELECT * FROM Book WHERE (BookName LIKE ? OR Content LIKE ?) AND IsDeleted = 0";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, "%" + keyword + "%");
                ps.setString(2, "%" + keyword + "%");
                ResultSet rs = ps.executeQuery();
                List<Book> books = new ArrayList<>();
                while (rs.next()) {
                    Book book = new Book();
                    book.setBookId(rs.getInt("BookId"));
                    book.setBookName(rs.getString("BookName"));
                    book.setContent(rs.getString("Content"));
                    books.add(book);
                }

                if (books.isEmpty()) {
                    System.out.println("Không tìm thấy sách phù hợp.");
                } else {
                    System.out.println("Kết quả tìm kiếm:");
                    for (Book book : books) {
                        book.displayData();
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                connectionDB.closeConnection(conn, null);
            }
        }
    }
}
