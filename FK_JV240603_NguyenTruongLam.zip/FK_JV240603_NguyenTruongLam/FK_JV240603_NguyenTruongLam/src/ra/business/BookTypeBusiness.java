package ra.business;

import java.sql.*;
import ra.entity.BookType;
import ra.util.ConnectionDB;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static ra.util.ConnectionDB.openConnection;

public class BookTypeBusiness {
    private ConnectionDB connectionDB;

    public BookTypeBusiness() {
        connectionDB = new ConnectionDB();
    }

    //  Hiển thị danh sách các loại sách chưa xóa trong bảng
    public List<BookType> getAllBookTypes() {
        List<BookType> bookTypes = new ArrayList<>();
        Connection conn = connectionDB.openConnection();
        if (conn != null) {
            try {
                String query = "SELECT * FROM BookType WHERE IsDeleted=0";
                Statement statement = conn.createStatement();
                ResultSet rs = statement.executeQuery(query);
                while (rs.next()) {
                    BookType bookType = new BookType();
                    bookType.setTypeId(rs.getInt("TypeId"));
                    bookType.setTypeName(rs.getString("TypeName"));
                    bookType.setDescription(rs.getString("Description"));
                    bookType.setDeleted(rs.getBoolean("IsDeleted"));
                    bookTypes.add(bookType);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                connectionDB.closeConnection(conn, null);
            }
        }
        return bookTypes;
    }

    // tạo mới loại sách
    public void addBookType(Scanner scanner) {
        BookType bookType = new BookType();
        bookType.inputData(scanner);
        Connection conn = connectionDB.openConnection();
        if (conn != null) {
            try {
                String query = "INSERT INTO BookType (TypeName, Description) VALUES(?,?)";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, bookType.getTypeName());
                ps.setString(2, bookType.getDescription());
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0){
                    System.out.println("Tạo mới danh sách thành công.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                connectionDB.closeConnection(conn, null);
            }
        }
    }

    // 4. Xóa loại sách
    public void deleteBookType(Scanner scanner) {
        System.out.println("Nhập mã loại sách cần xoá: ");
        int typeId = scanner.nextInt();

        Connection conn = connectionDB.openConnection();
        if (conn != null) {
            try {
                String update = "UPDATE BookType SET IsDeleted=1 WHERE TypeId=?";
                PreparedStatement ps = conn.prepareStatement(update);
                ps.setInt(1, typeId);
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0){
                    System.out.println("Xoá loại sách thành công.");
                }else {
                    System.out.println("Không tìm thấy loại sách.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }finally {
                connectionDB.closeConnection(conn, null);
            }
        }
    }

    // Thống kê số lượng sách theo mã loại sách
    public void statisticsBookByType(){
            Connection conn = connectionDB.openConnection();
            if (conn != null) {
                try {
                    String query = "SELECT bt.TypeName, COUNT(b.BookId) AS SOLUONG FROM Book b " +
                            "INNER JOIN BookType bt ON b.TypeId = bt.TypeId WHERE b.IsDeleted=0 " +
                            "GROUP BY bt.TypeName";
                    Statement statement = conn.createStatement();
                    ResultSet rs = statement.executeQuery(query);
                    System.out.println("Thống kê số lượng sách theo loại sách: ");
                    while (rs.next()) {
                        System.out.println("Loại sách: " + rs.getString("TypeName") + " - Số lượng " + rs.getInt("SOLUONG"));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    connectionDB.closeConnection(conn, null);
                }
            }
    }
}












