package ra.entity;

import java.util.Scanner;

public interface IBookManagement {
    void inputData(Scanner scanner);
    void displayData();
}
