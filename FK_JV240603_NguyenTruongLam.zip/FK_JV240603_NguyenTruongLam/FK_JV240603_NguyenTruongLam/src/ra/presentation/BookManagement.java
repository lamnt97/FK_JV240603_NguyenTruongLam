package ra.presentation;

import com.sun.security.jgss.GSSUtil;
import ra.business.BookBusiness;
import ra.business.BookTypeBusiness;
import ra.entity.Book;
import ra.entity.BookType;

import java.sql.SQLOutput;
import java.util.Scanner;

public class BookManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BookTypeBusiness bookTypeBusiness = new BookTypeBusiness();
        BookBusiness bookBusiness = new BookBusiness();

        while (true) {
            System.out.println("******************BOOK-MANAGEMENT******************");
            System.out.println("1.Quản lý loại sách");
            System.out.println("2.Quản lý sách");
            System.out.println("3.Thoát");
            System.out.println("Lựa chọn của bạn: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    bookTypeMenu(scanner, bookTypeBusiness);
                    break;
                case 2:
                    break;
                case 3:
                    System.out.println("Thoát chương trình");
                    return;
                default:
                    System.out.println("Lựa chọn không hợp lệ");
            }
        }
    }

    // Menu quản lý loại sách
    public static void bookTypeMenu(Scanner scanner,BookTypeBusiness bookTypeBusiness) {
        while(true){
            System.out.println("**********************BOOKTYPE-MENU********************");
            System.out.println("1.Danh sách loại sách");
            System.out.println("2.Tạo mới loại sách");
            System.out.println("3.Cập nhật thông tin loại sách");
            System.out.println("4.Xoá loại sách");
            System.out.println("5.Thống kê số lượng sách theo mã loại sách");
            System.out.println("6.Thoát");
            System.out.println("Lựa chọn của bạn: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    for (BookType bookType : bookTypeBusiness.getAllBookTypes()) {
                        bookType.displayData();
                    }
                    break;
                case 2:
                    bookTypeBusiness.addBookType(scanner);
                    break;
                case 3:
                    break;
                case 4:
                    bookTypeBusiness.deleteBookType(scanner);
                    break;
                case 5:
                    bookTypeBusiness.statisticsBookByType();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Lựa chọn không hợp lệ");
            }
        }
    }

    // Menu quản lý sách
    public static void bookMenu(Scanner scanner, BookBusiness bookBusiness) {
        while(true){
            System.out.println("**********************BOOK-MENU*******************");
            System.out.println("1. Danh sách sách");
            System.out.println("2. Tạo mới sách");
            System.out.println("3. Cập nhật thông tin sách");
            System.out.println("4. Xóa sách");
            System.out.println("5. Hiển thị danh sách các cuốn sách theo giá giảm dần");
            System.out.println("6. Tìm kiếm sách theo tên hoặc nội dung");
            System.out.println("7. Thống kê số lượng sách theo nhóm ");
            System.out.println("8. Thoát");
            System.out.println("Lựa chọn của bạn: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    for (Book book : bookBusiness.getAllBooks()){
                        book.displayData();
                    }
                    break;
                case 2:
                    bookBusiness.addBook(scanner);
                    break;
                case 3:
                    bookBusiness.updateBook(scanner);
                    break;
                case 4:
                    bookBusiness.deleteBook(scanner);
                    break;
                case 5:
                    bookBusiness.displayBooksByPriceDescending();
                    break;
                case 6:
                    bookBusiness.searchBookByNameOrContent(scanner);
                    break;
                case 8:
                    return;
                default:
                    System.out.println("Lựa chọn không hợp lệ.");

            }

        }
    }
}


















